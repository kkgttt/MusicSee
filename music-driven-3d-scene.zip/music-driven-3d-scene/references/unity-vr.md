# Unity 与 OpenXR 移植参考

## 交付与读取

- [场景契约](../assets/music-scene.schema.json)采用 JSON Schema Draft 2020-12。读取 `kind: music-scene`、`schemaVersion: 1` 后再加载。遇到未知的版本，保留输入并要求使用匹配的读取器或显式迁移。
- [河岸样例](../assets/river-example.scene.json)用来检查资源引用、挂点、唱词、影幕、路线与天气的对齐。样例使用示意数据，替换资源时保持 ID 稳定，随项目以相对路径交付对应资源与来源信息。
- 在技能目录运行 `node scripts/validate-scene.mjs assets/river-example.scene.json`，也可以传入待移植的场景文件。提交给 Unity 前，使用项目中的实际资源核对 glTF 节点、音视频解码与材质表现。运行 `node scripts/validate-scene.mjs --self-test` 可检查随包验证器的正反例。
- 加上 `--sample 3` 可查看指定歌曲时间的活动 cue、当句歌词和期望视频时间。验证器核对数据结构、引用和时间关系。交接时另行核对资源文件、可选的 SHA-256、实际媒体时长和节点路径。

## 数据与 Unity 端的职责

| 契约 | Unity 端的接入点 |
|---|---|
| `assets`、`instances` | 用资源 ID 解析 URI 与质量档，实例的 `pose` 定义根节点在场景中的位置和朝向。保留稳定 ID，场景切换或资源换档时按同一 ID 重绑。 |
| `anchors` | `pose` 是世界姿态，也用于绑定失败时回退。有 `instanceId` 和 `nodePath` 时优先使用该实例的命名节点变换。检查资产导入和换档后该路径仍唯一可达，避免对节点变换再叠加一次世界回退姿态。 |
| `route`、`camera` 类型的 cue | 路线从 0 秒到曲终，按 `atSec` 递增。默认可在相邻节点间线性插值位置并沿最短弧插值姿态。桌面镜头用 `desktopPose` 构图，手动环顾时交还控制权。头显将 `anchorId` 用作世界内的观看提示。 |
| `colliders`、`interactions` | 从锚点生成以米为单位的盒体，使用目标引擎的碰撞层。按 `action` 分派鼠标、手柄射线或可访问输入，目标资产由 `targetAssetId` 解析。 |
| `cues`、`song` | 音轨提供歌时，题签读取歌曲元数据。用 `weather.profileId` 选择目标端的雪、雾、雨或花瓣配置。天气和灯光的 `intensity` 为 0 到 1 的权重，灯色使用 sRGB。 |
| `capabilities` | 记录桌面手动观察、XR 跟踪视角、静止或用户主动开启的随舟移动，以及射线交互。由应用根据平台和设备条件启用。 |
| `performanceProfiles` | 桌面与头显按各自设备预算配置。记录刷新率、帧时间与可见画面，再按设备证据选择渲染档。 |

在目标端决定题签和字幕布局。前奏通常从歌曲元数据生成题签，并在首个唱词 cue 前淡出。项目如另有片头入点或实画可见性规则，将它们随交接文档记录。原画慢载或出框时，按当句时间显示底部字幕。桌面相机按歌时重建过渡，可在 `fadeInSec` 内从上一镜末端过渡到本镜，间隔段从路线视角起步。暂停与拖动复用同一插值规则。

## 坐标与挂点

契约世界使用右手系、米制，+X 向右、+Y 向上、−Z 向前。Unity 世界用 +X 向右、+Y 向上、+Z 向前。对 **JSON 世界数据**应用一次反射 `C = diag(1, 1, -1)`。点和方向 `[x,y,z]` 转为 `[x,y,-z]`，例如河右岸挂点 `[2,1,-5]` 转为 `[2,1,5]`，左岸仍在负 X 一侧。导出时将 `forward` 与 `up` 归一化并正交化，验证器允许长度和点积有 0.001 的误差。分别映射两个方向，再用 `Quaternion.LookRotation` 构造 Unity 姿态。若在内部用旋转矩阵表达同一姿态，两侧基底均转换时用 `C R C⁻¹`。盒体尺寸保持为正，已有世界 AABB 应转换八角再取边界。 [Unity 坐标与旋转](https://docs.unity3d.com/6000.0/Documentation/Manual/QuaternionAndEulerRotationsInUnity.html)

GLB 按 glTF 局部轴约定交给导入器。glTF 的 +Y 向上、+Z 为资产正面方向，资产的右侧为 −X。导入时核对 Blender 中定义的船艏、剑柄、窗檐、镜头挂点和底面。若导入器已把网格及节点转换到 Unity 轴向，直接使用导入结果。绑定场景实例时将转换后的 JSON 世界姿态放到实例根节点，让导入后的挂点继承根变换。 [glTF 坐标与单位](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#coordinate-system-and-units)

## 歌时、媒体与头显

1. 音频播放层负责播放、暂停、快进快退和重游。Unity 可用 `AudioSettings.dspTime` 为音频起播建锚，按 `起播歌时 + (当前 DSP 时间 - 起播 DSP 时间) × 播放速率` 采样。暂停时保存歌时，恢复、拖动后重新建锚。用解码或音源采样位置测量同步，并检查暂停、重载或设备音频重配置后的连续性。 [Unity 音频 DSP 时钟](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/AudioSettings-dspTime.html)
2. 唱词、原画、路线、相机、灯光和天气统一读歌时。Cue 的显示窗口用 `[startSec, endSec)`，同一拍交接时只由接入的窗口接管。唱词 `words` 的起止使用绝对歌时，气象与粒子按歌时、`song.seed` 和 cue ID 求值，便于暂停和双向拖动时复现。重游可显式选择新种子。
3. MV 的目标帧时间为 `sourceInSec + (songTime - startSec)`。`sourceInSec` 已落在对应媒体时间轴上，`calibrationOffsetSec` 记录校准依据，运行时直接使用已校准的绝对入点。可选的 `sourceOutSec` 等于入点加原速画面窗口长度。两段高潮可以复用一个静音媒体播放器。预热与寻帧期间按需显示 `fallbackImageAssetId`，待当前段的目标帧到位再切换。记录解码就绪与实际呈现时点时使用可得到的对应信号，分别报告首次切入、拖动恢复和稳态偏差。
4. OpenXR 运行时提供头显跟踪和每眼投影。让 XR Origin 承担参考空间与用户主动移动，保留跟踪驱动的头部局部位置、旋转和视场。使用世界锚点上的灯光、指示或在安全范围内的场景布局提示观看方向。桌面自动摇镜的角度和持续时间仅用于桌面构图。XR 中若采用随舟移动，做可进入和退出的体验，并在头显内复核移动舒适度。 [Unity XR Origin](https://docs.unity3d.com/6000.0/Documentation/Manual/xr-origin.html) · [Unity OpenXR 插件](https://docs.unity3d.com/Packages/com.unity.xr.openxr@1.14/manual/index.html)

## 从 Folia 长河提取

在 Folia 仓库根目录定位实际文件，先用当前部署版本和本地媒体校验后再转录。

| 源文件 | 可复用的内容 |
|---|---|
| `assets/scenes/虞美人/manifest.json` | 场景资产、米制定位和交互信息。 |
| `assets/scenes/虞美人/story.json`、`src/changhe-story.js` | 同版本媒体校验信息、原词源毫秒映射、逐字时长、27 幅原画和母片偏移。将逐字时间转换为绝对秒。校准后保存一次绝对入点。 |
| `assets/scenes/虞美人/mv-projections.json`、`src/changhe-mv-timeline.js`、`src/changhe-media.js` | 两段完整高潮、侧幕 cues、母片时间采样、静音视频与关键帧回退。 |
| `src/changhe-river.js`、`src/changhe-navigation.js`、`src/changhe-chorus.js`、`src/changhe-look.js` | 随舟路线、行走、碰撞和桌面分镜。为可移动资产重新核对挂点与镜头边距。 |
| `src/changhe-chorus-fx.js`、`src/changhe-sun-path.js`、`src/changhe-winter-willow.js` | 局部天气、天际与季节变化的触发点和参数。Unity 中重建对应渲染，复测水岸落点与遮挡。 |

旧版 `src/portable-data.js` 和 `assets/portable/schema.json` 提供 Folia 的通用 portable v1。调试入口 `__folia.exportPortable()` 可供核查通用数据。长河路线、高潮构图、水岸净空和媒体同步需要从上表对应来源提取并检查。本技能的独立契约由上述场景样例演示。

## 移植验收

- 先在普通视窗核对 1 米比例、左右岸、船艏、挂点和碰撞盒。检查同一资产换质量档后取景和交互是否一致。
- 用同一媒体原速播放，在各 cue 边界、暂停与双向拖动处复核歌词、天气、视频的时间和落点。模拟素材慢载，确认回退画面和准备好的目标帧都对应当前歌时。
- 用目标头显实测跟踪、双眼可读性、手柄射线、观看提示与退出移动。分别记录桌面和头显质量档、帧时间与媒体同步偏差。技能所附样例和验证器覆盖数据交接。
