# Web 运行与浏览器验收

## 入口、输入和页面生命周期

- 沿用应用的正式路由、播放器和主题切换。核对默认进入、带参数直达、刷新恢复、返回原页和换歌。用于定点取景的调试参数放在开发入口，正式路径用真实歌曲验证。Folia 的 `src/main.js` 有主题参数 `tid` 和持久化主题键 `folia.theme.id`，回归时覆盖带参入口和普通入口。
- 轨道镜头按歌时采样，鼠标和触屏输入临时调整视角。处理 `pointerup`、`pointercancel` 和捕获丢失，进度条拖动只改歌曲时间。监听页面可见性，回到前台时从实际歌时重取镜头、画面、特效和字幕，并丢弃隐藏期间的渲染时间差。
- 等待音频 `play()` 的 Promise 后再更新播放状态。遇到 `NotAllowedError`，给出明确的播放入口，必要时在同一用户手势里恢复 `AudioContext`。切歌、暂停或拆卸期间处理过期的 Promise。 [HTML 媒体规范](https://html.spec.whatwg.org/multipage/media.html)

## 加载、解码和慢加载

- 提前请求即将显示的图像、代表帧和视频元数据，等图像解码完成再挂纹理。把 `preload` 当作提示，按已解码帧决定露出时机。先显示本段代表帧，读取或解码失败时回到河景，字幕仍按歌时采样。
- 用浏览器 Network 核对资源 URL、状态码、MIME、跨域请求和媒体 Range。Folia 的 `src/changhe-media.js` 用 `Range: bytes=0-0` 探测服务端。返回 `206` 时用原 URL，旧服务端返回整段 MP4 时复用本次响应生成 Blob URL。整片转 Blob 会提高内存和冷启成本，优先在部署入口验证分段传输。
- 同一母片的连续片段复用一个静音 `HTMLVideoElement` 和 `VideoTexture`。歌曲时钟决定母片目标时间，`currentTime` 用于定位和校正。用 `requestVideoFrameCallback` 的 `mediaTime` 记录浏览器提交合成的帧，统计同一采样点相对于目标时间的偏差。缺少该 API 时仍可播放，测量注明使用播放头估计。 [视频帧回调规范](https://wicg.github.io/video-rvfc/)
- 给媒体请求和事件监听绑定当前会话标记或 `AbortController`。旧请求即使完成也只能为其会话提交资源。换歌与退出时取消帧回调、暂停并清空源、撤销 Blob URL，释放独占视频纹理。用慢网、快速来回拖动和加载中换歌验证状态不会回滚。

## Three.js 透明、尺寸和资源

- 让地形和不透明主体先写深度。给影幕画心单独写深度，深度材质用 `colorWrite:false` 并按羽化遮罩剔除边缘。彩色影幕保留 `depthTest`，设 `depthWrite:false`。用 `renderOrder` 协调透明影幕和近景粒子，反射通路也检查遮挡和裁切。关闭旧图层时显式设置 `visible = false`。 [Three.js 材质文档](https://threejs.org/docs/pages/Material.html)
- 用容器 CSS 尺寸更新相机宽高比和字幕安全区，单独记录 drawing buffer 尺寸及实际 DPR。缩放时同步更新后处理和反射目标的尺寸，避免每帧重建缓冲。移出场景后释放独占 geometry、material、texture 和 render target，共享资源在最后一个使用者退出后释放。 [Three.js 响应式尺寸](https://threejs.org/manual/pages/responsive.html) · [资源释放](https://threejs.org/manual/pages/how-to-dispose-of-objects.html)

## 快速复测

1. 从正式入口原速播放关键段。用相同浏览器、画质、CSS 尺寸、drawing buffer 和歌时记录对照，另跑窄屏和触屏。按[歌时与分镜验收](music-camera-qa.md)核对首字、舞台遮挡、四角和歌词落点。
2. 用 DevTools Network 限速与禁用缓存测冷加载，记录首次可见帧、拖动恢复和素材失败时是否可继续播放。另测热播，分别报渲染帧时间和音画偏差 P95。标明性能预算与实际结果，例如 60 FPS 对应整帧约 16.7 毫秒。 [Chrome DevTools 性能参考](https://developer.chrome.com/docs/devtools/performance/reference)
3. 卡顿时检查 Performance 的长任务、帧轨和纹理上传，结合 `renderer.info` 检查 draw calls 和资源数，区分主视图与反射等额外渲染。优先减少超预算场景的远层粒子和雾光密度。切歌和退场后复测资源数是否回到合理水平。
