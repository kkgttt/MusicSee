import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { isDeepStrictEqual } from 'node:util';

function readJson(file) {
  return JSON.parse(readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
}

const schema = readJson(new URL('../assets/music-scene.schema.json', import.meta.url));
const typeChecks = {
  object: (value) => value !== null && typeof value === 'object' && !Array.isArray(value),
  array: Array.isArray,
  string: (value) => typeof value === 'string',
  number: Number.isFinite,
  integer: Number.isInteger,
  boolean: (value) => typeof value === 'boolean'
};

// Validate the keywords used by the bundled schema. Cue alternatives have distinct kind literals.
function checkShape(value, rule, path) {
  if (rule.$ref) {
    const definition = rule.$ref.slice('#/$defs/'.length);
    return checkShape(value, schema.$defs[definition], path);
  }
  if (rule.oneOf) {
    const alternative = rule.oneOf.find((candidate) => candidate.properties.kind.const === value?.kind);
    return alternative ? checkShape(value, alternative, path) : path + '.kind must identify a known cue';
  }
  if (rule.type && !typeChecks[rule.type](value)) return path + ' must be ' + rule.type;
  if (Object.hasOwn(rule, 'const') && !isDeepStrictEqual(value, rule.const)) {
    return path + ' must equal ' + JSON.stringify(rule.const);
  }
  if (rule.enum && !rule.enum.includes(value)) return path + ' must be one of ' + rule.enum.join(', ');
  if (rule.minimum !== undefined && value < rule.minimum) return path + ' is below its minimum';
  if (rule.exclusiveMinimum !== undefined && value <= rule.exclusiveMinimum) return path + ' is below its exclusive minimum';
  if (rule.maximum !== undefined && value > rule.maximum) return path + ' exceeds its maximum';
  if (rule.minLength !== undefined && value.length < rule.minLength) return path + ' must not be empty';
  if (rule.pattern && !new RegExp(rule.pattern, 'u').test(value)) return path + ' has an invalid format';
  if (rule.items) {
    if (value.length < (rule.minItems ?? 0) || value.length > (rule.maxItems ?? Infinity)) {
      return path + ' has an invalid length';
    }
    for (const [index, item] of value.entries()) {
      const error = checkShape(item, rule.items, path + '[' + index + ']');
      if (error) return error;
    }
  }
  if (rule.properties) {
    for (const key of rule.required) {
      if (!Object.hasOwn(value, key)) return path + '.' + key + ' is required';
    }
    for (const [key, item] of Object.entries(value)) {
      const childPath = path + '.' + key;
      if (!Object.hasOwn(rule.properties, key)) {
        if (rule.additionalProperties === false) return childPath + ' is not supported';
        continue;
      }
      const error = checkShape(item, rule.properties[key], childPath);
      if (error) return error;
    }
  }
  return null;
}

function indexById(items, collection, errors) {
  const index = new Map();
  for (const item of items) {
    if (index.has(item.id)) errors.push(collection + ' has duplicate ID ' + item.id);
    index.set(item.id, item);
  }
  return index;
}

function checkBasis(pose, label, errors) {
  const { forward, up } = pose;
  const dot = forward.reduce((sum, component, axis) => sum + component * up[axis], 0);
  const tolerance = 0.001;
  if (Math.abs(Math.hypot(...forward) - 1) > tolerance ||
      Math.abs(Math.hypot(...up) - 1) > tolerance || Math.abs(dot) > tolerance) {
    errors.push(label + ' must have perpendicular unit forward and up vectors');
  }
}

function checkUri(uri, label, errors) {
  const invalidSegment = uri.split('/').some((segment) => {
    return segment === '.' || segment === '..' || segment !== segment.trim() || segment.endsWith('.');
  });
  if (invalidSegment) errors.push(label + ' must be a portable package-relative path');
}

function checkDisjoint(cues, kind, errors) {
  const sorted = cues.filter((cue) => cue.kind === kind).sort((a, b) => a.startSec - b.startSec);
  let previous = null;
  for (const cue of sorted) {
    if (previous && cue.startSec < previous.endSec) {
      errors.push(kind + ' cues overlap (' + previous.id + ', ' + cue.id + ')');
    }
    if (!previous || cue.endSec > previous.endSec) previous = cue;
  }
}

function validate(scene) {
  const shapeError = checkShape(scene, schema, '$');
  if (shapeError) return [shapeError];

  const errors = [];
  const assets = indexById(scene.assets, 'assets', errors);
  const instances = indexById(scene.instances, 'instances', errors);
  const anchors = indexById(scene.anchors, 'anchors', errors);
  indexById(scene.colliders, 'colliders', errors);
  indexById(scene.interactions, 'interactions', errors);
  indexById(scene.cues, 'cues', errors);

  function requireAsset(id, kind, label) {
    const asset = assets.get(id);
    if (!asset || (kind && asset.kind !== kind)) {
      errors.push(label + ' must reference an existing ' + (kind ?? 'asset') + ' ID (' + id + ')');
      return null;
    }
    return asset;
  }

  function requireAnchor(id, label) {
    if (!anchors.has(id)) errors.push(label + ' must reference an existing anchor (' + id + ')');
  }

  const duration = scene.song.durationSec;
  const audio = requireAsset(scene.song.audioAssetId, 'audio', 'song.audioAssetId');
  if (audio?.durationSec !== undefined && duration > audio.durationSec + 0.000001) {
    errors.push('song.durationSec exceeds the audio duration');
  }
  for (const asset of scene.assets) {
    const label = 'asset ' + asset.id;
    checkUri(asset.uri, label, errors);
    if (asset.durationSec !== undefined && !['audio', 'video'].includes(asset.kind)) {
      errors.push(label + ' durationSec is only valid for audio or video');
    }
    if (asset.variants) {
      if (asset.kind !== 'model') errors.push(label + ' LOD variants require a model asset');
      const levels = new Set();
      for (const variant of asset.variants) {
        if (levels.has(variant.level)) errors.push(label + ' repeats LOD ' + variant.level);
        levels.add(variant.level);
        checkUri(variant.uri, label + ' LOD ' + variant.level, errors);
      }
    }
  }
  for (const instance of scene.instances) {
    requireAsset(instance.assetId, 'model', 'instance ' + instance.id);
    checkBasis(instance.pose, 'instance ' + instance.id, errors);
  }
  for (const anchor of scene.anchors) {
    const label = 'anchor ' + anchor.id;
    checkBasis(anchor.pose, label, errors);
    if (Object.hasOwn(anchor, 'instanceId') !== Object.hasOwn(anchor, 'nodePath')) {
      errors.push(label + ' requires instanceId and nodePath together');
    }
    if (anchor.instanceId && !instances.has(anchor.instanceId)) {
      errors.push(label + ' must reference an existing instance (' + anchor.instanceId + ')');
    }
  }
  for (const collider of scene.colliders) requireAnchor(collider.anchorId, 'collider ' + collider.id);
  for (const interaction of scene.interactions) {
    requireAnchor(interaction.anchorId, 'interaction ' + interaction.id);
    if (interaction.targetAssetId) requireAsset(interaction.targetAssetId, null, 'interaction ' + interaction.id);
  }
  if (scene.route[0].atSec !== 0 || scene.route.at(-1).atSec !== duration) {
    errors.push('route must span song time from 0 to song.durationSec');
  }
  let previousRouteTime = -1;
  for (const [index, point] of scene.route.entries()) {
    if (point.atSec <= previousRouteTime) errors.push('route[' + index + '] must increase in song time');
    previousRouteTime = point.atSec;
    checkBasis(point.pose, 'route[' + index + ']', errors);
  }
  for (const cue of scene.cues) {
    const label = 'cue ' + cue.id;
    const length = cue.endSec - cue.startSec;
    if (length <= 0 || cue.endSec > duration) errors.push(label + ' must have a positive window inside the song');
    if ((cue.fadeInSec ?? 0) + (cue.fadeOutSec ?? 0) > length + 0.000001) {
      errors.push(label + ' fade durations exceed its window');
    }
    if (cue.anchorId) requireAnchor(cue.anchorId, label);
    if (cue.kind === 'art') requireAsset(cue.assetId, 'image', label);
    if (cue.kind === 'camera') checkBasis(cue.desktopPose, label + '.desktopPose', errors);
    if (cue.kind === 'video') {
      const video = requireAsset(cue.assetId, 'video', label);
      const requiredEnd = cue.sourceInSec + length;
      if (cue.sourceOutSec !== undefined && Math.abs(cue.sourceOutSec - requiredEnd) > 0.000001) {
        errors.push(label + ' sourceOutSec must equal sourceInSec plus its window length');
      }
      if (video?.durationSec !== undefined && requiredEnd > video.durationSec + 0.000001) {
        errors.push(label + ' exceeds the video duration');
      }
      if (cue.fallbackImageAssetId) requireAsset(cue.fallbackImageAssetId, 'image', label + '.fallbackImageAssetId');
    }
    if (cue.kind === 'lyric') {
      let previousWordEnd = cue.startSec;
      for (const [index, word] of cue.words.entries()) {
        if (word.startSec < previousWordEnd || word.endSec <= word.startSec || word.endSec > cue.endSec) {
          errors.push(label + '.words[' + index + '] must be ordered and inside its lyric window');
        }
        previousWordEnd = word.endSec;
      }
    }
  }
  for (const kind of ['lyric', 'video', 'camera']) checkDisjoint(scene.cues, kind, errors);
  return errors;
}

function sample(scene, songSec) {
  const active = scene.cues.filter((cue) => cue.startSec <= songSec && songSec < cue.endSec);
  const lyric = active.find((cue) => cue.kind === 'lyric');
  const video = active.find((cue) => cue.kind === 'video');
  return {
    songSec,
    seed: scene.song.seed,
    cueIds: active.map((cue) => cue.id),
    lyric: lyric?.text ?? null,
    video: video ? {
      assetId: video.assetId,
      sourceSec: video.sourceInSec + (songSec - video.startSec)
    } : null
  };
}

function selfTest() {
  const example = readJson(new URL('../assets/river-example.scene.json', import.meta.url));
  assert.deepEqual(validate(example), []);
  const mutations = [
    ['schemaVersion', (scene) => { scene.schemaVersion = 2; }],
    ['duplicate ID', (scene) => { scene.assets.push(scene.assets[0]); }],
    ['existing audio', (scene) => { scene.song.audioAssetId = 'skiff'; }],
    ['package-relative', (scene) => { scene.assets[0].uri = 'media/../song.ogg'; }],
    ['invalid format', (scene) => { scene.assets[0].uri = 'C:/song.ogg'; }],
    ['must increase', (scene) => { scene.route[1].atSec = 0; }],
    ['perpendicular unit', (scene) => { scene.route[0].pose.up = [0, 0, -1]; }],
    ['existing instance', (scene) => { scene.anchors[3].instanceId = 'missing-skiff'; }],
    ['instanceId and nodePath', (scene) => { delete scene.anchors[3].nodePath; }],
    ['existing anchor', (scene) => { scene.colliders[0].anchorId = 'missing-anchor'; }],
    ['lyric window', (scene) => { scene.cues[2].words[1].startSec = 1.1; }],
    ['sourceOutSec', (scene) => { scene.cues[3].sourceOutSec += 0.1; }],
    ['video duration', (scene) => { scene.assets[1].durationSec = 5; }],
    ['video cues overlap', (scene) => { scene.cues.push({ ...scene.cues[3], id: 'overlap' }); }],
    ['fade durations', (scene) => { scene.cues[0].fadeOutSec = 3; }],
    ['inside the song', (scene) => { scene.cues.at(-1).endSec = 11; }]
  ];
  for (const [expected, mutate] of mutations) {
    const invalid = structuredClone(example);
    mutate(invalid);
    assert.ok(validate(invalid).some((error) => error.includes(expected)), expected);
  }

  assert.equal(sample(example, 0).lyric, null);
  assert.equal(sample(example, 1).lyric, '晚风过岸');
  assert.equal(sample(example, 2.6).lyric, null);
  assert.ok(sample(example, 2.999).cueIds.includes('willow-art'));
  assert.ok(!sample(example, 3).cueIds.includes('willow-art'));
  assert.equal(sample(example, 3).video.sourceSec, 3.0465);
  assert.equal(sample(example, 6).video, null);
  assert.ok(sample(example, 6).cueIds.includes('dusk-sky'));
  assert.deepEqual(sample(example, 10).cueIds, []);
  const before = sample(example, 3.5);
  assert.deepEqual(sample(example, 3.5), before);
  sample(example, 7);
  assert.deepEqual(sample(example, 3.5), before);

  const playlist = structuredClone(example);
  playlist.cues.push({
    ...playlist.cues[3], id: 'west-film', anchorId: 'west-screen',
    startSec: 6, endSec: 7, sourceInSec: 6.0465, sourceOutSec: 7.0465
  });
  assert.deepEqual(validate(playlist), []);
  const handoff = sample(playlist, 6);
  assert.ok(handoff.cueIds.includes('west-film') && !handoff.cueIds.includes('east-film'));
  assert.equal(handoff.video.sourceSec, 6.0465);

  const reflectZ = ([x, y, z]) => [x, y, z === 0 ? 0 : -z];
  assert.deepEqual(reflectZ(example.anchors[1].pose.position), [2, 2.6, 7]);
  assert.deepEqual(reflectZ(example.anchors[0].pose.position), [-2, 2.4, 4]);
  assert.deepEqual(reflectZ(example.route.at(-1).pose.forward), [0.6, 0, 0.8]);
  assert.deepEqual(reflectZ(example.route.at(-1).pose.up), [0, 1, 0]);
  console.log('PASS bundled scene, ' + mutations.length + ' invalid scenes, cue sampling and coordinate examples');
}

function main(args) {
  if (args.length === 1 && args[0] === '--self-test') {
    selfTest();
    return;
  }
  const [file, option, rawTime] = args;
  if (!file || file.startsWith('--') || (args.length !== 1 && !(args.length === 3 && option === '--sample'))) {
    throw new Error('Usage: node scripts/validate-scene.mjs <scene.json> [--sample <song-seconds>] or --self-test');
  }
  const scene = readJson(file);
  const errors = validate(scene);
  if (errors.length) throw new Error(errors.join('\n'));

  if (option === '--sample') {
    const songSec = Number(rawTime);
    if (!rawTime.trim() || !Number.isFinite(songSec) || songSec < 0 || songSec > scene.song.durationSec) {
      throw new Error('--sample requires song time inside [0, song.durationSec]');
    }
    console.log(JSON.stringify(sample(scene, songSec), null, 2));
    return;
  }
  console.log('PASS ' + scene.id + ' (' + scene.cues.length + ' cues)');
}

try {
  main(process.argv.slice(2));
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
