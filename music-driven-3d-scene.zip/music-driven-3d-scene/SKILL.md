---
name: music-driven-3d-scene
description: 围绕歌词和音乐编排 MV、原画与三维意象，处理侧幕投影、动态天空、换镜、遮挡和媒体同步。也适用于随舟或步行观画、Blender 与实时场景制作，以及向 Unity 或 OpenXR 交接场景。
---

# 音乐驱动的三维场景

## 开工顺序

1. 从正常入口复看问题段，核对原曲版本、歌词尾音、母片和素材。截图用于定位歌时附近的镜头，实际入点和源帧再用原曲与媒体验证。
2. 先给素材定用途。原画可落在岸边，连续高潮可落在世界侧幕，风景或回忆可成为天空，片尾意象可接到实体。将唱词、画面可读区间、运镜和预热分别记录在同一歌曲时钟上。
3. 在实际取景里摆好影幕、主体和遮挡，再调透明边、环境光、水面和天气。需要建模时先用灰盒验取景与碰撞，再换 Blender 精修和 GLB。
4. 用实帧复核从上一镜到下一镜的完整过程。区分镜头反摆、实体遮挡、帧率尖峰和媒体寻帧。以原速、暂停、双向拖动、窄屏和手动环顾验证改动，跨引擎时同时交付坐标、挂点、媒体与时序。

## 按任务读参考

| 任务 | 参考 |
|---|---|
| MV、原画与意象选材，影幕、动态天空、实体交接与回退 | [MV、原画与场景意象](references/mv-and-imagery.md) |
| 灰盒、Blender、建模返工、GLB 与 LOD、实时水岸和影幕材质 | [灰盒、资产与渲染](references/asset-and-render.md) |
| 逐字歌词、画面时序、摄像机换岸、MV 同步与实机验证 | [音乐时钟、分镜与实机验收](references/music-camera-qa.md) |
| Web 入口、浏览器媒体、Three.js 生命周期和 WebGL 性能 | [Web 运行与验收](references/web-runtime.md) |
| 导出场景数据、改用 Unity 或接入 XR | [Unity 与 OpenXR 移植](references/unity-vr.md) |

## 场景数据交接

按 [v1 数据契约](assets/music-scene.schema.json) 和 [合成样例](assets/river-example.scene.json) 制作交接文件。样例 URI 是用于校验的示意路径。真实移植时携带匹配的媒体、模型和命名挂点，并在目标引擎核对它们。

在技能目录运行以下命令，或传入待交接的 JSON 文件。

```sh
node scripts/validate-scene.mjs assets/river-example.scene.json
node scripts/validate-scene.mjs assets/river-example.scene.json --sample 3
node scripts/validate-scene.mjs --self-test
```
