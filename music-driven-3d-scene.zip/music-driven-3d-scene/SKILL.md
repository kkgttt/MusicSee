---
name: music-driven-3d-scene
description: 制作、精修和交接音乐驱动的三维场景。适用于 Folia 长河一类的随舟或步行观画、场景灰盒、Blender 精修和 GLB、Web 与 Three.js 渲染、实时天气与水岸、歌词分镜与 MV 投影，以及向 Unity 或 OpenXR 移植同一套场景数据。
---

# 音乐驱动的三维场景

## 开工顺序

1. 查项目的正常入口、真实音轨和母片、现有场景表、资产源文件、时钟与相机控制。用正常入口留一个可复核的基准。把媒体版本、歌时秒数、场景坐标和运行端分开记。
2. 先做灰盒。把可走区域、碰撞、河道路线、主体轮廓和取景挂点摆进实际播放镜头。分别复看稳定构图、左右岸换镜和窄屏。对照歌词和关键帧，确认意象的季节、材质、尺度、位置和遮挡关系。
3. 稳定根节点和挂点后再精修。保留 Blender 源文件，导出并回读轻量 GLB。先做主体、接触、遮挡与反射，再做局部光和粒子。让天气与水岸共享落点、时钟和种子。
4. 把唱词、原画、影幕、飞行路径、天气、灯光和相机绑定到同一歌曲时间。给每段保留稳定 ID；用实听或实帧决定入点、尾音和转场。分别验证正常播放、暂停、双向拖动、环顾、慢载和重游。
5. 从当前范围交付可复用的资产、配置和验证证据。跨引擎时输出可校验的数据，按目标渲染器和输入设备做独立适配与验收。

## 按任务读参考

| 任务 | 参考 |
|---|---|
| 灰盒、Blender、建模返工、GLB 与 LOD、实时水岸和影幕材质 | [灰盒、资产与渲染](references/asset-and-render.md) |
| 逐字歌词、画面时序、摄像机换岸、MV 同步与实机验证 | [音乐时钟、分镜与实机验收](references/music-camera-qa.md) |
| Web 入口、浏览器媒体、Three.js 生命周期和 WebGL 性能 | [Web 运行与验收](references/web-runtime.md) |
| 导出场景数据、改用 Unity 或接入 XR | [Unity 与 OpenXR 移植](references/unity-vr.md) |

## 场景数据交接

按 [v1 数据契约](assets/music-scene.schema.json) 和 [合成样例](assets/river-example.scene.json) 制作交接文件。样例 URI 是用于校验的示意路径。真实移植时携带匹配的媒体、模型和命名挂点，并在目标引擎核对它们。

在技能目录运行以下命令，或传入待交接的 JSON 文件。

```sh
node scripts/validate-scene.mjs assets/river-example.scene.json
node scripts/validate-scene.mjs assets/river-example.scene.json --sample 3
node scripts/validate-scene.mjs --self-test
```
